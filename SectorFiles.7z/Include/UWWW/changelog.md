Ufa custom sector - beta
#### Added
-AD Pervushino
-Closed TWYs labels, TWYs to grass RWY
-Prohibinted and restricted zone
-Non-RNAV procedures
-Heliport
-Stands near Hangars
-H markings
-Int and Domestic terminal markings
-1C stand
-An-2 stand
#### Changed
-Ufa-start freq 120.9
#### Fixed
#### Deleted
#### Notes
Have a nice control
